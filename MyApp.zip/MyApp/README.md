# My App(Android Internship Assignment)
 
[![Build Status](https://travis-ci.org/joemccann/dillinger.svg?branch=master)](https://travis-ci.org/joemccann/dillinger)

    -IDE: android studio 3.5
    -Android version : Lollipop 5.0-5.1.1
    -Database :SQL lite
    
 ### Download APK

 Click here to download [APK](https://drive.google.com/file/d/1gpn6ArYpsrMhehAKLGwCj4XQOlUcUuIA/view?usp=sharing) .
            OR
Extract .zip file . APK file is available in  " My APP/app-debug.apk" path.            

  
## Some links
- GitHUB - [https://github.com/shamithshetty](https://github.com/shamithshetty)
- LinkedIn- [https://www.linkedin.com/in/shamith-shetty-17065614b/](https://www.linkedin.com/in/shamith-shetty-17065614b/)
- Imstagram-shamith.shetty777
  
 