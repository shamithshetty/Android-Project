package com.example.myapp.First;

import android.content.Context;
import android.content.SharedPreferences;


public class PrefManager {
    public SharedPreferences pref;
    SharedPreferences.Editor editor;
    Context _context;

    // shared pref mode
    int PRIVATE_MODE = 0;

    // Shared preferences file name
    private static final String PREF_NAME = "start_welcome";

    private static final String IS_LOGGED_IN = "IsFirstTimeLaunch";
    private static final String GET_MAIL = "Email";


    public PrefManager(Context context) {
        this._context = context;
        pref = _context.getSharedPreferences(PREF_NAME, PRIVATE_MODE);
        editor = pref.edit();
    }

    public void setLoggedIn(boolean isFirstTime) {
        editor.putBoolean(IS_LOGGED_IN, isFirstTime);
        editor.commit();
    }

    public boolean isLoggedIn() {
        return pref.getBoolean(IS_LOGGED_IN, true);
    }

    public String getEmail(){
        return pref.getString(GET_MAIL,"");

    }
    public void setEmail(String email){
        editor.putString(GET_MAIL,email).apply();
    }

}