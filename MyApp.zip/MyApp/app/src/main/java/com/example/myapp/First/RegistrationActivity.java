package com.example.myapp.First;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.Model.User;
import com.example.myapp.R;
import com.example.myapp.Sql.DatabaseHelper;
import com.example.myapp.Validation.Validate;

public class RegistrationActivity extends AppCompatActivity {

    private EditText fname,lname,email,pass,addr,mbl;
    private Button signup;
    private DatabaseHelper databaseHelper;
    private Validate validate;
    private User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        // Making notification bar transparent
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            getWindow().setStatusBarColor(getResources().getColor(R.color.white));
        }
        mapping();
        databaseHelper = new DatabaseHelper(this);
        validate=new Validate();
        user = new User();
        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                postDataToSQLite();
            }
        });

    }
    private void mapping(){
        fname=findViewById(R.id.txtfname);
        lname=findViewById(R.id.txtlname);
        email=findViewById(R.id.txtemail);
        pass=findViewById(R.id.txtpass);
        mbl=findViewById(R.id.txtmbl);
        addr=findViewById(R.id.txtaddr);
        signup=findViewById(R.id.signup);
    }
    public void onClickmovelogin(View v)
    {
        startActivity(new Intent(this,LoginActivity.class));
        overridePendingTransition(R.anim.slide_in_left,android.R.anim.slide_out_right);
    }
    private void postDataToSQLite() {
        if(validated()) {
            if (!databaseHelper.checkUser(email.getText().toString().trim())) {
                user.setFname(fname.getText().toString().trim());
                user.setLname(lname.getText().toString().trim());
                user.setEmail(email.getText().toString().trim());
                user.setPass(pass.getText().toString().trim());
                user.setAddr(addr.getText().toString().trim());
                user.setMbl(mbl.getText().toString().trim());
                databaseHelper.addUser(user);
                Toast.makeText(this, "sucessfull", Toast.LENGTH_SHORT).show();
                startActivity(new Intent(this, LoginActivity.class));
                overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
                finish();
            } else {
                Toast.makeText(this, "Your Already exist", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean validated() {
        boolean b=true;
        if(!validate.isEmpty(fname.getText().toString().trim())){
            fname.setError("F name can not be empty  ");
            b=false;
        }
        if(!validate.isEmail(email.getText().toString().trim())){
            email.setError("Invalid Email ID ");
            b=false;
        }
        if(!validate.isPassword(pass.getText().toString().trim())){
            pass.setError("password contain more than 5 character ");
            b=false;
        }
        if(!validate.isEmpty(lname.getText().toString().trim())){
            lname.setError("L name can not be empty ");
            b=false;
        }
        if(!validate.isEmpty(addr.getText().toString().trim())){
            addr.setError("Address can not ne empty ");
            b=false;
        }
        if(!validate.isMbl(mbl.getText().toString().trim())){
            mbl.setError("Invalid mbl number");
            b=false;
        }
        return b;
    }
}