package com.example.myapp.Validation;

import android.util.Patterns;

public class Validate {

    public Validate() {
    }
    public boolean isMbl(String mbl){
        String regex = "(0/91)?[7-9][0-9]{9}";
        return mbl.matches(regex);
    }
    public boolean isEmail(String email){
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
    public boolean isFname(String fname){
        return fname.matches( "[A-Z][a-z]*" );
    }
    public boolean isLname(String lname){
        return lname.matches( "[A-Z]+([ '-][a-zA-Z]+)*" );
    }
    public boolean isEmpty(String str){
        return str.length()>0 ? true :false;
    }
    public boolean isPassword(String str){
        return str.length()>6  ? true :false;
    }

}
