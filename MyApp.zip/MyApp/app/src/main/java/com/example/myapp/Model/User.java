package com.example.myapp.Model;

public class User {
    private  String Fname,Lname,Email,Addr,Pass,Mbl;

    public User() {
    }

    public User(String fname, String lname, String email, String addr, String pass, String mbl) {
        Fname = fname;
        Lname = lname;
        Email = email;
        Addr = addr;
        Pass = pass;
        Mbl = mbl;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAddr() {
        return Addr;
    }

    public void setAddr(String addr) {
        Addr = addr;
    }

    public String getPass() {
        return Pass;
    }

    public void setPass(String pass) {
        Pass = pass;
    }

    public String getMbl() {
        return Mbl;
    }

    public void setMbl(String mbl) {
        Mbl = mbl;
    }
}
