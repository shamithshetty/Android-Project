package com.example.myapp;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import android.os.Handler;
import android.os.TestLooperManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.Adapeter.ListAdapter;
import com.example.myapp.Adapeter.TabFragmentAdapter;
import com.example.myapp.First.LoginActivity;
import com.example.myapp.Fragment.PAge2Fragment;
import com.example.myapp.Fragment.Page1Fragment;
import com.example.myapp.Model.Lists;
import com.facebook.shimmer.ShimmerFrameLayout;
import com.example.myapp.SortJson;
import com.google.android.material.tabs.TabLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class HomeFragment extends Fragment {

    private TextView tname,tabout,turl;
    //tab
    TabLayout mTabs;
    View mIndicator;
    ViewPager mViewPager;
    private int indicatorWidth;

    public HomeFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inf=inflater.inflate(R.layout.fragment_home, container, false);

        tname=inf.findViewById(R.id.txtname);
        tabout=inf.findViewById(R.id.txtabout);
        turl=inf.findViewById(R.id.txturl);
        addData();
        //Assign view reference
        mTabs = inf.findViewById(R.id.tab);
        mIndicator = inf.findViewById(R.id.indicator);
        mViewPager = inf.findViewById(R.id.viewPager);
        //Set up the view pager and fragments
        TabFragmentAdapter adapter = new TabFragmentAdapter(getChildFragmentManager());
        adapter.addFragment(new Page1Fragment(), "PAGE1");
        adapter.addFragment(new PAge2Fragment(), "PAGE2");
        mViewPager.setAdapter(adapter);
        mTabs.setupWithViewPager(mViewPager);
        //Determine indicator width at runtime
        mTabs.post(new Runnable() {
            @Override
            public void run() {
                indicatorWidth = mTabs.getWidth() / mTabs.getTabCount();
                //Assign new width
                FrameLayout.LayoutParams indicatorParams = (FrameLayout.LayoutParams) mIndicator.getLayoutParams();
                indicatorParams.width = indicatorWidth;
                mIndicator.setLayoutParams(indicatorParams);
            }
        });
        mViewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {


            @Override
            public void onPageScrolled(int i, float positionOffset, int positionOffsetPx) {
                FrameLayout.LayoutParams params = (FrameLayout.LayoutParams)mIndicator.getLayoutParams();

                //Multiply positionOffset with indicatorWidth to get translation
                float translationOffset =  (positionOffset+i) * indicatorWidth ;
                params.leftMargin = (int) translationOffset;
                mIndicator.setLayoutParams(params);
            }

            @Override
            public void onPageSelected(int i) {

            }

            @Override
            public void onPageScrollStateChanged(int i) {

            }
        });

        return inf;
    }

    private void addData() {
        String url = "https://reqres.in/api/users?page=1";
        StringRequest request = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(final String string) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        parseJsonData(string);
                    }
                },2000);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Intent accountsIntent = new Intent(getContext(), ErrorActivity.class);
                startActivity(accountsIntent);
                getActivity().overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(getActivity());
        rQueue.add(request);
    }
    void parseJsonData(String jsonString) {
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONObject ob = object.getJSONObject("ad");
            tname.setText(ob.getString("company"));
            tabout.setText(ob.getString("text"));
            turl.setText(ob.getString("url"));

        } catch (JSONException e) {
            Intent accountsIntent = new Intent(getContext(), ErrorActivity.class);
            startActivity(accountsIntent);
            getActivity().overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
        }
    }

}