package com.example.myapp.First;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;

import com.example.myapp.MainActivity;
import com.example.myapp.R;

public class SplashActivity extends AppCompatActivity {

    private PrefManager prefManager;
    private static int SPLASH_TIME_OUT=1000;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        // Making notification bar transparent
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            getWindow().setStatusBarColor(getResources().getColor(R.color.white));
        }
        prefManager = new PrefManager(this);
        //delay code
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent=null;
                if (!prefManager.isLoggedIn()) {
                    intent=new Intent(getApplicationContext(), MainActivity.class);
                }else{
                    intent=new Intent(getApplicationContext(), LoginActivity.class);
                }
                overridePendingTransition(R.anim.slide_in_right,R.anim.stay);
                startActivity(intent);
                overridePendingTransition(R.anim.slide_in_right,R.anim.stay);
                finish();
            }
        },SPLASH_TIME_OUT);

    }
}