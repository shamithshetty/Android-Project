package com.example.myapp.Model;

public class Lists {
    private String Id,Fname,Lname,Email,Avatar;

    public Lists(String id, String fname, String lname, String email, String avatar) {
        Id = id;
        Fname = fname;
        Lname = lname;
        Email = email;
        Avatar = avatar;
    }

    public Lists() {
    }

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String getFname() {
        return Fname;
    }

    public void setFname(String fname) {
        Fname = fname;
    }

    public String getLname() {
        return Lname;
    }

    public void setLname(String lname) {
        Lname = lname;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getAvatar() {
        return Avatar;
    }

    public void setAvatar(String avatar) {
        Avatar = avatar;
    }
}
