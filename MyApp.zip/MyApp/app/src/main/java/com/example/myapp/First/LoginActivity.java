package com.example.myapp.First;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.myapp.MainActivity;
import com.example.myapp.Model.User;
import com.example.myapp.R;
import com.example.myapp.Sql.DatabaseHelper;
import com.example.myapp.Validation.Validate;

public class LoginActivity extends AppCompatActivity {

    private Button login;
    private EditText email,pass;
    private DatabaseHelper databaseHelper;
    private PrefManager prefManager;
    private Validate validate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        // Making notification bar transparent
        if (Build.VERSION.SDK_INT >= 21) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
            getWindow().setStatusBarColor(getResources().getColor(R.color.white));
        }
        mapping();
        databaseHelper = new DatabaseHelper(this);
        validate=new Validate();
        prefManager = new PrefManager(this);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                loginCheck();
            }
        });
    }

    private void loginCheck() {
        if(validated()) {
            if (databaseHelper.checkUser(email.getText().toString().trim()
                    , pass.getText().toString().trim())) {
                prefManager.setLoggedIn(false);
                prefManager.setEmail(email.getText().toString().trim());
                Intent accountsIntent = new Intent(this, MainActivity.class);
                startActivity(accountsIntent);
                overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
                finish();
            } else {
                Toast.makeText(this, "invalid user id password", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean validated() {
        boolean b=true;
        if(!validate.isEmail(email.getText().toString().trim())){
            email.setError("Invalid Email ID ");
            b=false;
        }
        if(!validate.isPassword(pass.getText().toString().trim())){
            pass.setError("password contain more than 5 character ");
            b=false;
        }
        return b;

    }

    public void onClickmoveregistration(View v) {
        startActivity(new Intent(this,RegistrationActivity.class));
        overridePendingTransition(R.anim.slide_in_right,R.anim.stay);
        finish();
    }
    private void mapping(){
        email=findViewById(R.id.txtemail);
        pass=findViewById(R.id.txtpassword);
        login=findViewById(R.id.login);
    }
}