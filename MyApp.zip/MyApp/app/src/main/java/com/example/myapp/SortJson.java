package com.example.myapp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.*;
import org.json.*;
public class SortJson {

    public JSONArray sortjson(JSONArray jarr){
        try{
            JSONArray sortedJsonArray = new JSONArray();
            List list = new ArrayList();
            for(int i = 0; i < jarr.length(); i++) {
                list.add(jarr.getJSONObject(i));
            }
            Collections.sort(list, new Comparator() {
                private static final String KEY_NAME = "first_name";
                @Override
                public int compare(Object a, Object b) {
                    String str1 = new String();
                    String str2 = new String();
                    try {
                        str1 = (String)((JSONObject)a).get(KEY_NAME);
                        str2 = (String)((JSONObject)b).get(KEY_NAME);
                    } catch(JSONException e) {

                    }
                    return str1.compareTo(str2);
                }
            });

            for(int i = 0; i < jarr.length(); i++) {
                sortedJsonArray.put(list.get(i));
            }
            return sortedJsonArray;
        }catch (Exception e){
            return null;
        }
    }

}
