package com.example.myapp.Fragment;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.myapp.Adapeter.ListAdapter;
import com.example.myapp.ErrorActivity;
import com.example.myapp.Model.Lists;
import com.example.myapp.R;
import com.example.myapp.SortJson;
import com.facebook.shimmer.ShimmerFrameLayout;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


public class Page1Fragment extends Fragment {

    RecyclerView recyclerView;
    String url = "https://reqres.in/api/users?page=1";
    LinearLayoutManager linearLayoutManager;
    ArrayList<Lists> rowsArrayList;
    ListAdapter listAdapter;
    private ShimmerFrameLayout mShimmerViewContainer;
    public Page1Fragment() {
        // Required empty public constructor
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inf=inflater.inflate(R.layout.fragment_page1, container, false);

        recyclerView = (RecyclerView) inf.findViewById(R.id.recyclerView);
        //inital display
        linearLayoutManager= new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(linearLayoutManager);
        rowsArrayList=new ArrayList<>();
        mShimmerViewContainer = inf.findViewById(R.id.shimmer_view_container);
        //delay code

        StringRequest request = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(final String string) {
                new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        parseJsonData(string);
                        mShimmerViewContainer.stopShimmerAnimation();
                        mShimmerViewContainer.setVisibility(View.GONE);
                        recyclerView.setVisibility(View.VISIBLE);
                    }
                },2000);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError volleyError) {
                Intent accountsIntent = new Intent(getContext(), ErrorActivity.class);
                startActivity(accountsIntent);
                getActivity().overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
            }
        });

        RequestQueue rQueue = Volley.newRequestQueue(getActivity());
        rQueue.add(request);
        return inf;
    }
        void parseJsonData(String jsonString) {
        try {
            JSONObject object = new JSONObject(jsonString);
            JSONArray arr = object.getJSONArray("data");
            JSONArray array=(new SortJson().sortjson(arr));
            for(int i = 0; i < array.length(); ++i) {
                JSONObject jobj=array.getJSONObject(i);
                rowsArrayList.add(new Lists(jobj.getString("id"),jobj.getString("first_name"),jobj.getString("last_name"),jobj.getString("email"),jobj.getString("avatar")));
            }
            listAdapter=new ListAdapter(getContext(),rowsArrayList);
            recyclerView.setAdapter(listAdapter);
        } catch (JSONException e) {
            Intent accountsIntent = new Intent(getContext(), ErrorActivity.class);
            startActivity(accountsIntent);
            getActivity().overridePendingTransition(R.anim.slide_in_left, android.R.anim.slide_out_right);
        }
    }
    @Override
    public void onResume() {
        super.onResume();
        mShimmerViewContainer.startShimmerAnimation();
    }


    @Override
    public void onPause() {
        mShimmerViewContainer.stopShimmerAnimation();
        super.onPause();
    }
}