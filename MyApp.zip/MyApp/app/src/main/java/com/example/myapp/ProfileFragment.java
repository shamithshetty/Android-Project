package com.example.myapp;

import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import de.hdodenhof.circleimageview.CircleImageView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapp.First.PrefManager;
import com.example.myapp.Model.User;
import com.example.myapp.Sql.DatabaseHelper;
import com.example.myapp.Validation.Validate;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;


public class ProfileFragment extends Fragment {

    private DatabaseHelper databaseHelper;
    private Validate validate;
    private TextView tname,temail,tmbl,taddr,txtemail,txtmbl,txtaddr;
    private RelativeLayout l1,l2,l3;
    User user;
    private PrefManager prefManager;
    String email;
    private CircleImageView edit1,edit2,edit3,btn1,btn2,btn3;
    public ProfileFragment() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View inf=inflater.inflate(R.layout.fragment_profile, container, false);
        // Inflate the layout for this fragment
        validate=new Validate();
        mapping(inf);
        clickevent();
        prefManager=new PrefManager(getContext());
        databaseHelper = new DatabaseHelper(getContext());
        email=prefManager.getEmail();
        addData();
        return inf;
    }

    private void clickevent() {
        edit1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                l1.setVisibility(View.VISIBLE);
                tmbl.setVisibility(View.GONE);
            }
        });
        edit2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                l2.setVisibility(View.VISIBLE);
                temail.setVisibility(View.GONE);
            }
        });
        edit3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                l3.setVisibility(View.VISIBLE);
                taddr.setVisibility(View.GONE);
            }
        });
        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate.isMbl(txtmbl.getText().toString().trim())){
                    user.setMbl(txtmbl.getText().toString().trim());
                    databaseHelper.updateUser(user);
                    l1.setVisibility(View.GONE);
                    tmbl.setVisibility(View.VISIBLE);
                    tmbl.setText(txtmbl.getText().toString().trim());
                }else{
                    txtmbl.setError("Invalid mbl");
                }
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate.isEmail(txtemail.getText().toString().trim())){
                    user.setEmail(txtemail.getText().toString().trim());
                    databaseHelper.updateUser(user);
                    l2.setVisibility(View.GONE);
                    temail.setVisibility(View.VISIBLE);
                    temail.setText(txtemail.getText().toString().trim());
                }else{
                    txtemail.setError("Invalid email");
                }
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(validate.isEmpty(txtaddr.getText().toString().trim())){
                    user.setAddr(txtaddr.getText().toString().trim());
                    databaseHelper.updateUser(user);
                    l3.setVisibility(View.GONE);
                    taddr.setVisibility(View.VISIBLE);
                    taddr.setText(txtaddr.getText().toString().trim());
                }else{
                    txtaddr.setError("Invalid Address");
                }
            }
        });
    }

    private void mapping(View inf) {
        tname=inf.findViewById(R.id.txtname);
        temail=inf.findViewById(R.id.txtemail);
        taddr=inf.findViewById(R.id.txtaddr);
        tmbl=inf.findViewById(R.id.txtmbl);
        txtemail=inf.findViewById(R.id.temail);
        txtaddr=inf.findViewById(R.id.taddr);
        txtmbl=inf.findViewById(R.id.tmbl);
        edit1=inf.findViewById(R.id.edit1);
        edit3=inf.findViewById(R.id.edit3);
        edit2=inf.findViewById(R.id.edit2);
        l1=inf.findViewById(R.id.txt1);
        l2=inf.findViewById(R.id.txt2);
        l3=inf.findViewById(R.id.txt3);
        btn1=inf.findViewById(R.id.btn1);
        btn2=inf.findViewById(R.id.btn2);
        btn3=inf.findViewById(R.id.btn3);
    }

    private void addData() {
        user=databaseHelper.getUser(email);
        tname.setText(""+user.getFname()+" "+user.getLname());
        temail.setText(user.getEmail());
        taddr.setText(user.getAddr());
        tmbl.setText(user.getMbl());
        txtemail.setText(user.getEmail());
        txtaddr.setText(user.getAddr());
        txtmbl.setText(user.getMbl());
    }

}