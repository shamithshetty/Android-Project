package com.example.myapp.Adapeter;

import android.content.Context;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.myapp.Model.Lists;
import com.example.myapp.R;
import com.squareup.picasso.Picasso;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.recyclerview.widget.RecyclerView;
import de.hdodenhof.circleimageview.CircleImageView;

public class ListAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    public List<Lists> mlist;
    public Context context;
    boolean b=false;
    public ListAdapter(Context c,List<Lists> mlist) {
        this.mlist = mlist;
        context=c;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list, parent, false);
        return new ListAdapter.ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        populateItemRows((ListAdapter.ItemViewHolder) holder, position);
    }

    @Override
    public int getItemCount() {
        return mlist.size();
    }
    private class ItemViewHolder extends RecyclerView.ViewHolder {
        TextView txtname,txtemail,txtid;
        CircleImageView img;
        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            img=(CircleImageView) itemView.findViewById(R.id.img);
            txtname = (TextView) itemView.findViewById(R.id.txtname);
            txtemail = (TextView) itemView.findViewById(R.id.txtemail);
            txtid = (TextView) itemView.findViewById(R.id.txtid);
        }
    }
    private void populateItemRows(ListAdapter.ItemViewHolder viewHolder, final int position) {
        final Lists lists=mlist.get(position);
        viewHolder.txtname.setText(lists.getFname()+" "+lists.getLname());
        viewHolder.txtemail.setText(lists.getEmail().toString().trim());
        viewHolder.txtid.setText("ID :"+lists.getId());
        Picasso.get()
                .load(lists.getAvatar().isEmpty() ? null : lists.getAvatar())
                .placeholder(R.drawable.demo)
                .error(R.drawable.demo)
                .into(viewHolder.img);
        ((RecyclerView.ViewHolder)viewHolder).itemView.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View view) {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle("Confirm");
                builder.setMessage("Are you sure?");

                builder.setPositiveButton("YES", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // Do nothing but close the dialog
                        mlist.remove(position);
                        notifyDataSetChanged();
                        dialog.dismiss();
                    }
                });

                builder.setNegativeButton("NO", new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        b=false;
                        dialog.dismiss();
                    }
                });
                AlertDialog alert = builder.create();
                alert.show();
                return false;
            }
        });
    }

}
